<#
.SYNOPSIS
    nfl-stat-cli Run-Once Installer for Windows.
    Usage:
      .\install.ps1        Compact UI (ASCII Art + Full-Width Progress Bar + 1-Line Live Command)
      .\install.ps1 -v     Verbose mode (full command and pip output)
#>
param(
    [Alias("v")]
    [switch]$VerboseMode = $false,
    [switch]$WithSLM = $false,
    [switch]$SkipLivePackages = $false
)

$ErrorActionPreference = "Continue"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
Set-Location $ProjectRoot
$LogFile = Join-Path $env:TEMP "nfl_stat_cli_install.log"
"" | Set-Content -Path $LogFile -Encoding UTF8 -ErrorAction SilentlyContinue

function Find-RealPython {
    $MachinePath = [System.Environment]::GetEnvironmentVariable("Path", "Machine")
    $UserPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
    $Combined = "$env:Path;$UserPath;$MachinePath"
    $env:Path = (($Combined -split ";") | Where-Object { $_ -ne "" } | Select-Object -Unique) -join ";"

    $candidates = @("python", "python3", "py")
    foreach ($cmd in $candidates) {
        $found = Get-Command $cmd -ErrorAction SilentlyContinue
        if ($found -and $found.Source -notmatch "WindowsApps") {
            try {
                $ver = & $found.Source -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')" 2>$null
                if ($LASTEXITCODE -eq 0 -and $ver -match "^3\.") {
                    return $found.Source
                }
            } catch {}
        }
    }

    $searchDirs = @(
        "$env:LocalAppData\Programs\Python\Python312\python.exe",
        "$env:LocalAppData\Programs\Python\Python311\python.exe",
        "$env:LocalAppData\Programs\Python\Python310\python.exe",
        "C:\Program Files\Python312\python.exe",
        "C:\Program Files\Python311\python.exe",
        "C:\Python312\python.exe"
    )
    foreach ($p in $searchDirs) {
        if (Test-Path $p) {
            return $p
        }
    }
    return $null
}

$BarInnerWidth = 82  # '[' (1) + 82 + '] ' (2) + '100%' (4) = 89 chars total (matches banner width)

function Update-CompactUI([int]$Percent, [string]$CommandText) {
    if ($VerboseMode) { return }
    $filled = [Math]::Floor(($Percent * $BarInnerWidth) / 100)
    $empty = $BarInnerWidth - $filled
    $barStr = "[" + ("#" * $filled) + ("-" * $empty) + ("] {0,3}%" -f $Percent)
    $cleanCmd = ($CommandText -replace "[\r\n]+", " ")
    if ($cleanCmd.Length -gt 85) {
        $cleanCmd = $cleanCmd.Substring(0, 85)
    }
    $esc = [char]27
    [Console]::Write("`r$esc[2K$esc[1A`r$esc[2K")
    Write-Host $barStr -ForegroundColor Yellow
    [Console]::Write("> " + $cleanCmd)
}

if ($VerboseMode) {
    Write-Host "======================================================================" -ForegroundColor Cyan
    Write-Host "  NFL-STAT-CLI : One-Step Automated Installer (Windows) [VERBOSE MODE]" -ForegroundColor Yellow
    Write-Host "======================================================================" -ForegroundColor Cyan
} else {
    $PythonPreview = Find-RealPython
    if ($PythonPreview) {
        & $PythonPreview -c "import nfl_stat_cli; print(nfl_stat_cli.AsciiArtRenderer.banner())" 2>$null
    } else {
        Write-Host "+=======================================================================================+" -ForegroundColor Yellow
        Write-Host "|  NFL-STAT-CLI : nflverse (R) + sportsdataverse-py (Python) Custom Stat & Play Engine  |" -ForegroundColor Cyan
        Write-Host "+=======================================================================================+" -ForegroundColor Yellow
    }
    Write-Host ""
    Update-CompactUI 5 "Checking Python 3 installation..."
}

# 1. Ensure Python 3 is installed
$PythonExe = Find-RealPython
if (-not $PythonExe) {
    if ($VerboseMode) { Write-Host "[1/5] Python 3 not found. Installing Python 3.12..." -ForegroundColor Yellow }
    else { Update-CompactUI 10 "winget install -e --id Python.Python.3.12" }
    $winget = Get-Command winget -ErrorAction SilentlyContinue
    if ($winget) {
        if ($VerboseMode) {
            & winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements
        } else {
            & winget install -e --id Python.Python.3.12 --scope user --accept-package-agreements --accept-source-agreements >>$LogFile 2>&1
        }
    }
    $PythonExe = Find-RealPython
    if (-not $PythonExe) {
        if (-not $VerboseMode) { Update-CompactUI 15 "Downloading python-3.12.8-amd64.exe from python.org..." }
        $installerUrl = "https://www.python.org/ftp/python/3.12.8/python-3.12.8-amd64.exe"
        $installerPath = Join-Path $env:TEMP "python-3.12.8-amd64.exe"
        Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath -UseBasicParsing
        Start-Process -FilePath $installerPath -ArgumentList "/quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_test=0" -Wait
        Remove-Item $installerPath -Force -ErrorAction SilentlyContinue
        $PythonExe = Find-RealPython
    }
    if (-not $PythonExe) {
        Write-Host ""
        Write-Host "ERROR: Could not automatically install Python 3." -ForegroundColor Red
        exit 1
    }
}
if ($VerboseMode) { Write-Host "[1/5] Using Python: $PythonExe" -ForegroundColor Green }
else { Update-CompactUI 20 "Using Python: $PythonExe" }

# 2. Ensure virtual environment (.venv) and pip are ready
$VenvDir = Join-Path $ProjectRoot ".venv"
$VenvPy = Join-Path $VenvDir "Scripts\python.exe"
if (-not (Test-Path $VenvPy)) {
    if ($VerboseMode) { Write-Host "[2/5] Creating virtual environment in .venv..." -ForegroundColor Cyan }
    else { Update-CompactUI 25 "$PythonExe -m venv .venv" }
    & $PythonExe -m venv $VenvDir >>$LogFile 2>&1
}
if (Test-Path $VenvPy) {
    & $VenvPy -m pip --version >>$LogFile 2>&1
    if ($LASTEXITCODE -eq 0) {
        $PythonExe = $VenvPy
    } else {
        Remove-Item $VenvDir -Recurse -Force -ErrorAction SilentlyContinue
    }
}

if ($VerboseMode) { Write-Host "[2/5] Checking pip..." -ForegroundColor Cyan }
else { Update-CompactUI 28 "$PythonExe -m pip --version" }
& $PythonExe -m pip --version >>$LogFile 2>&1
if ($LASTEXITCODE -ne 0) {
    if (-not $VerboseMode) { Update-CompactUI 32 "$PythonExe -m ensurepip --upgrade" }
    & $PythonExe -m ensurepip --upgrade >>$LogFile 2>&1
}
if (-not $VerboseMode) { Update-CompactUI 40 "$PythonExe -m pip install --upgrade pip setuptools wheel" }
& $PythonExe -m pip install --upgrade pip setuptools wheel --quiet >>$LogFile 2>&1

# 3. Install required Python packages & nfl-stat-cli
if (-not $SkipLivePackages) {
    if ($VerboseMode) {
        Write-Host "[3/5] Installing NFL analytics Python packages (pandas, pyarrow, polars, nfl_data_py, nflreadpy)..." -ForegroundColor Cyan
        & $PythonExe -m pip install --only-binary=:all: pandas pyarrow polars
        & $PythonExe -m pip install nfl_data_py
        & $PythonExe -m pip install --only-binary=:all: nflreadpy >>$LogFile 2>&1
    } else {
        Update-CompactUI 55 "pip install --only-binary=:all: pandas pyarrow polars"
        & $PythonExe -m pip install --only-binary=:all: pandas pyarrow polars --quiet >>$LogFile 2>&1
        Update-CompactUI 75 "pip install nfl_data_py"
        & $PythonExe -m pip install nfl_data_py --quiet >>$LogFile 2>&1
        Update-CompactUI 82 "pip install --only-binary=:all: nflreadpy"
        & $PythonExe -m pip install --only-binary=:all: nflreadpy >>$LogFile 2>&1
    }
}

if ($VerboseMode) {
    Write-Host "      Installing nfl-stat-cli package..." -ForegroundColor Cyan
    & $PythonExe -m pip install -e . --no-build-isolation
} else {
    Update-CompactUI 90 "pip install -e . --no-build-isolation"
    & $PythonExe -m pip install -e . --no-build-isolation >>$LogFile 2>&1
}

# 4. Optional R & Optional Local SLM (Ollama)
$rscript = Get-Command Rscript -ErrorAction SilentlyContinue
if ($rscript) {
    if (-not $VerboseMode) { Update-CompactUI 94 "Rscript -e install.packages('nflreadr')" }
    & Rscript -e "if (!requireNamespace('nflreadr', quietly=TRUE)) install.packages('nflreadr', repos=c('https://nflverse.r-universe.dev', 'https://cloud.r-project.org'))" >>$LogFile 2>&1
}

if ($WithSLM) {
    $ollama = Get-Command ollama -ErrorAction SilentlyContinue
    if ($ollama) {
        if ($VerboseMode) { Write-Host "[4/5] Pulling local SLM model (qwen2.5:1.5b) via Ollama..." -ForegroundColor Cyan }
        else { Update-CompactUI 96 "ollama pull qwen2.5:1.5b" }
        & ollama pull qwen2.5:1.5b >>$LogFile 2>&1
    } elseif ($VerboseMode) {
        Write-Host "[4/5] Note: Ollama not found on PATH; skipping local SLM model pull." -ForegroundColor DarkYellow
    }
}

# 5. Ensure portable local folder launchers (nfl-stat.bat & nfl-stat-cli.bat) & verify
$LauncherContent = @"
@echo off
if exist "%~dp0.venv\Scripts\python.exe" (
    "%~dp0.venv\Scripts\python.exe" "%~dp0nfl_stat_cli.py" %*
) else (
    where py >nul 2>nul
    if %ERRORLEVEL% EQU 0 (
        py -3 "%~dp0nfl_stat_cli.py" %*
    ) else (
        python "%~dp0nfl_stat_cli.py" %*
    )
)
"@
Set-Content -Path (Join-Path $ProjectRoot "nfl-stat.bat") -Value $LauncherContent -Encoding ASCII
Set-Content -Path (Join-Path $ProjectRoot "nfl-stat-cli.bat") -Value $LauncherContent -Encoding ASCII

if ($VerboseMode) {
    Write-Host "[5/5] Verifying nfl-stat-cli installation..." -ForegroundColor Cyan
    & (Join-Path $ProjectRoot "nfl-stat.bat") list-stats
    $VerifyCode = $LASTEXITCODE
    if ($VerifyCode -eq 0) {
        Write-Host "  [OK] INSTALLATION COMPLETE! Run: .\nfl-stat" -ForegroundColor Green
    } else {
        Write-Host "  [!] Verification failed (see $LogFile)." -ForegroundColor Red
        exit $VerifyCode
    }
} else {
    Update-CompactUI 98 ".\nfl-stat.bat --version"
    & (Join-Path $ProjectRoot "nfl-stat.bat") --version >>$LogFile 2>&1
    $VerifyCode = $LASTEXITCODE
    if ($VerifyCode -eq 0) {
        Update-CompactUI 100 "Done! Run: .\nfl-stat  (or .\install.ps1 -v for verbose)"
        Write-Host ""
    } else {
        Update-CompactUI 100 "ERROR: Verification failed (log: $LogFile)."
        Write-Host ""
        exit $VerifyCode
    }
}

if ($VerifyCode -eq 0 -and [Environment]::UserInteractive) {
    $ans = Read-Host "? Add 'nfl-stat' to your PATH so you can run it from anywhere? [y/N]"
    if ($ans -match "^[yY]") {
        $CurrentUserPath = [System.Environment]::GetEnvironmentVariable("Path", "User")
        $PathParts = ($CurrentUserPath -split ";") | Where-Object { $_ -ne "" }
        if ($PathParts -notcontains $ProjectRoot) {
            $NewUserPath = ($PathParts + $ProjectRoot) -join ";"
            [System.Environment]::SetEnvironmentVariable("Path", $NewUserPath, "User")
        }
        if (($env:Path -split ";") -notcontains $ProjectRoot) {
            $env:Path = "$ProjectRoot;$env:Path"
        }
        Write-Host "[OK] Added '$ProjectRoot' to your PATH! You can now run 'nfl-stat' from anywhere." -ForegroundColor Green
    } else {
        Write-Host "Skipped adding to global PATH. You can run '.\nfl-stat' in this folder anytime." -ForegroundColor DarkGray
    }
}
