# nfl-stat-cli 🏈

A cross-platform (`*nix` and Windows) command-line interface and interactive terminal dashboard with **colorized ASCII art** (gridiron field diagrams, play visualizers, and formatted tables) that builds, tracks, and composes custom NFL statistics using **[nflverse](https://nflverse.nflverse.com/) (R)** and **[sportsdataverse-py](https://py.sportsdataverse.org/) (Python)**.

## Core Highlights

- **Cross-Platform Colorized Terminal UI (`*nix` & Windows)**: Enables native Windows 10/11 Virtual Terminal ANSI escape sequences alongside Linux/macOS terminals. Renders **100-yard ASCII Art Football Fields**, **Play Route & Screen Block Diagrams**, horizontal impact gauges, and clean Unicode box tables.
- **Dual Data Engine (`sportsdataverse-py` + `nflverse` R + Instant Offline Mode)**:
  - Pulls tidy play-by-play data in Python via [`sportsdataverse-py`](https://github.com/sportsdataverse/sportsdataverse-py) (`sportsdataverse.nfl.load_nfl_pbp`) or [`nflreadpy`](https://github.com/nflverse/nflreadpy).
  - Bridges directly to R's [`nflverse`](https://github.com/nflverse) (`nflreadr::load_pbp`, `nflfastR` EPA/WPA/CPOE/xYAC models) via `nflverse_bridge.R`.
  - Includes a built-in multi-season (`2024`–`2025`) offline dataset so every command works out of the box with zero setup.
- **Built-In Featured Analytics & Use Cases**:
  1. **MLB-Style QB Meaningful Wins (`qb_meaningful_win`), Inverse Losses (`qb_meaningful_loss`), & 0–100 Impact Score (`qb_impact_score`)**: Credits a quarterback with a Meaningful Win (`MW`) only when their team wins **and** their 0–100 Game Impact Score (weighted from EPA/play, WPA/game, CPOE, success rate, and turnover avoidance) is `>= 55.0`. Charges a Meaningful Loss (`ML`) when the team loses and the QB's Impact Score is `<= 42.0`; otherwise records a **No-Decision (`ND`)**.
  2. **Screen Pass Effectiveness (`screen_yards_after_catch`, `screen_effectiveness_index`)**: Evaluates screen passes by average yards gained, Yards After Catch (`YAC`), YAC Over Expected (`YACOE` via `xyac_mean_yardage`), and EPA, complete with an ASCII art screen-pass play diagram.
  3. **Conference Offensive Play Efficiency (`play-efficiency --conf AFC`)**: Ranks offensive concepts (`play_action_deep`, `screen`, `rush_outside`, `pass_intermediate`, `pass_short`) across the AFC or NFC by average yards gained and plots the top play onto the ASCII gridiron.
- **Composable Custom Stat Builder & Persistent Stat Page**:
  - Once a custom stat is created, it can be referenced inside new custom stat formulas alongside traditional stats (with automatic AST dependency resolution).
  - Every traditional and custom stat stores a full **Description** and **Calculation Explanation**.
  - Pin stats to your **Stat Page** (`~/.nfl_stat_cli/stat_page.json`) to track historical lookbacks (`2024`) and forward progress (`2025+`).
  - Export and upload/import custom stats in portable **JSON format** (`export-stats` / `import-stats`).
- **Zero Paid APIs Required**: Includes a built-in deterministic Natural Language Stat Assistant (`nfl-stat-cli ask "..."`) that runs locally at **$0 cost** with no paid cloud APIs or external login server needed.

## Quickstart (*nix & Windows)

```bash
# Launch interactive colorized TUI menu
python3 nfl_stat_cli.py

# Run MLB-style QB Meaningful Wins, Losses & 0-100 Impact Score report + ASCII field play
python3 nfl_stat_cli.py qb-wins --season 2025 --view all

# Analyze Screen Pass Effectiveness (Yards Gained, YAC, xYAC)
python3 nfl_stat_cli.py screen-pass --season 2025 --view all

# Show the most efficient offensive play in the AFC by yards gained
python3 nfl_stat_cli.py play-efficiency --conf AFC --season 2025 --view all

# Create a new custom stat built on top of existing custom stats + traditional stats
python3 nfl_stat_cli.py create-stat   --name "qb_clutch_win_index"   --title "QB Clutch Win Value Index"   --group-by qb   --formula "(qb_impact_score * 0.65) + (qb_meaningful_win * 12.0) - (qb_meaningful_loss * 15.0) + (yards_per_play * 1.5)"   --description "Second-order QB metric combining custom Impact Score, MW/ML record, and traditional YPP."   --explained "0.65 * qb_impact_score + 12 * qb_meaningful_win - 15 * qb_meaningful_loss + 1.5 * yards_per_play"   --unit "idx"

# View your persistent Stat Page (2024 lookback vs 2025 forward tracking)
python3 nfl_stat_cli.py stat-page

# Export and Import Custom Stats as JSON
python3 nfl_stat_cli.py export-stats --output custom_stats_export.json
python3 nfl_stat_cli.py import-stats --input custom_stats_export.json

# Ask a question in plain English (100% local, no paid APIs required)
python3 nfl_stat_cli.py ask "What is the effectiveness of screen pass for 2025 in yards after catch?"
```

## Installing Optional Live R & Python Data Packages

```bash
# Python (sportsdataverse-py & nflreadpy)
pip install --pre sportsdataverse nflreadpy pandas polars

# R (nflverse: nflreadr, nflfastR, nflseedR, nfl4th, nflplotR)
Rscript -e 'install.packages("nflverse", repos = c("https://nflverse.r-universe.dev", getOption("repos")))'
```

## License

MIT License. Play-by-play data provided via [nflverse/nflverse-data](https://github.com/nflverse/nflverse-data) (CC-BY 4.0) and [sportsdataverse-py](https://github.com/sportsdataverse/sportsdataverse-py).
